from django.contrib.auth import authenticate, login, logout
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.core.paginator import Paginator
from django.shortcuts import render, redirect
from .models import Karyawan, Bagian, Absen, Setting
from .forms import KaryawanCreateForm, KaryawanUpdateForm, BagianCreateForm, BagianUpdateForm, AbsenCreateForm, AbsenUpdateForm, SearchAbsenForm, SettingUpdateForm, PrintAbsenForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from bootstrap_datepicker_plus.widgets import DatePickerInput, TimePickerInput
from rest_framework.response import Response
from django.http import HttpResponse
from .serializers import AbsenSerializer
from rest_framework import status
from datetime import date
from rest_framework.decorators import api_view
from django.http import FileResponse
from django.db.models import Q
from datetime import datetime

from io import BytesIO
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import ParagraphStyle


def nama_hari(indonesia=True):
    nama_hari_indonesia = [
        'Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'
    ]

    def get_nama_hari(weekday):
        return nama_hari_indonesia[weekday]

    return get_nama_hari


def nama_bulan(ind):
    nama_bulan_indonesia = [
        'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli',
        'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ]

    if 1 <= ind <= 12:
        return nama_bulan_indonesia[ind - 1]
    else:
        return "Indeks bulan tidak valid"


def create_letter_template_bytesio(company_name, company_address, data):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer,
                            pagesize=A4,
                            leftMargin=72,
                            rightMargin=72,
                            topMargin=72,
                            bottomMargin=72)

    # Styles
    centered_style = ParagraphStyle('centered',
                                    alignment=1,
                                    textColor=colors.black,
                                    fontSize=16,
                                    leading=24)
    address_style = ParagraphStyle('address',
                                   alignment=1,
                                   textColor=colors.black,
                                   fontSize=10,
                                   leading=12)
    absensi_style = ParagraphStyle('absensi',
                                   alignment=1,
                                   textColor=colors.black,
                                   fontSize=12,
                                   leading=14)
    line_style2 = TableStyle([('BOTTOMPADDING', (0, 0), (-1, -1), 6,
                               colors.black),
                              ('LINEABOVE', (0, 0), (-1, 0), 2, colors.black)])
    line_style = TableStyle([('BOTTOMPADDING', (0, 0), (-1, -1), 6,
                              colors.black),
                             ('LINEABOVE', (0, 0), (-1, 0), 1, colors.black)])
    table_style = TableStyle([('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                              ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                              ('BOTTOMPADDING', (0, 0), (-1, 0), 6),
                              ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                              ('TEXTCOLOR', (0, 0), (-1, 0),
                               colors.whitesmoke),
                              ('LINEABOVE', (0, 0), (-1, 0), 1, colors.black),
                              ('GRID', (0, 0), (-1, -1), 1, colors.black)])

    additional_table_style = TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 2),
    ])

    additional_table2_style = TableStyle([
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, -1), 'Helvetica-Bold'),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 2),
    ])

    # Create content
    content = []

    # Company Name
    title_text = f"<b>{company_name}</b>"
    centered_text = Paragraph(title_text, centered_style)
    content.append(centered_text)

    # Company Address
    address_text = f"<font size=10>{company_address}</font>"
    address_paragraph = Paragraph(address_text, address_style)
    content.append(address_paragraph)

    # Spacer for separation
    content.append(Spacer(1, 18))  # Spacer for vertical separation

    # Line
    line = Table([[""]], colWidths=[520], rowHeights=[2])
    line2 = Table([[""]], colWidths=[520], rowHeights=[10])
    line.setStyle(line_style2)
    line2.setStyle(line_style)

    content.append(line)
    content.append(line2)

    # Spacer for separation
    content.append(Spacer(1, 12))  # Spacer for vertical separation

    absensi_text = "<b>Lembar Absensi Karyawan</b>"
    absensi_paragraph = Paragraph(absensi_text, absensi_style)
    content.append(absensi_paragraph)

    content.append(Spacer(1, 12))

    additional_table_data1 = [
        ["Nama", ":", data['nama'], " ", " ", " ", " "],
        ["Departemen", ":", data['bagian'], " ", " ", " ", " "],
        [
            "Bulan", ":", "{}, {}".format(data['bulan_indo'], data['tahun']),
            " ", " ", " ", " "
        ],
    ]

    additional_table1 = Table(additional_table_data1,
                              colWidths=[70, 20, 60, 20, 160, 60, 100])
    additional_table1.setStyle(additional_table_style)
    content.append(additional_table1)

    content.append(Spacer(1, 12))

    # Table Headers
    table_headers = [
        "No.", "Hari", "Tanggal", "Jam Datang", "Jam Pulang", "Status",
        "Keterangan"
    ]

    data_absen = [table_headers]

    for i, absen in enumerate(data['data']):
        hari_indonesia = nama_hari(indonesia=True)
        nama_hari_indonesia = hari_indonesia(absen.tgl_absen.weekday())

        data_absen.insert(i + 1, [
            i + 1, nama_hari_indonesia,
            absen.tgl_absen.strftime('%d-%m-%Y'),
            absen.jam_datang.strftime('%H:%M') if absen.jam_datang else " ",
            absen.jam_pulang.strftime('%H:%M') if absen.jam_pulang else " ",
            absen.status, absen.keterangan
        ])

    # Table
    table = Table(data_absen, colWidths=[50, 80, 80, 60, 60, 60, 100])
    table.setStyle(table_style)
    content.append(table)

    content.append(Spacer(1, 12))

    additional_table_data = [
        ["Jumlah Kehadiran", " ", ":", data['hadir'], " ", " ", " "],
        ["Izin", " ", ":", data['izin'], " ", " ", " "],
        ["Sakit", " ", ":", data['sakit'], " ", " ", " "],
        ["Tanpa Keterangan", " ", ":", data['tk'], " ", " ", " "]
    ]

    additional_table = Table(additional_table_data,
                             colWidths=[50, 60, 20, 20, 180, 60, 100])
    additional_table.setStyle(additional_table_style)
    content.append(additional_table)

    content.append(Spacer(1, 24))

    additional_table2_data = [
        ["Karyawan", " ", " ", " ", " ", " ", "Mengetahui"],
        [" ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " "],
        [
            "( {} )".format(data['nama']), " ", " ", " ", " ", " ",
            "( HR Manager )"
        ],
    ]

    additional_table2 = Table(additional_table2_data,
                              colWidths=[120, 20, 70, 70, 70, 20, 120])
    additional_table2.setStyle(additional_table2_style)
    content.append(additional_table2)

    content.append(Spacer(1, 12))

    # Build the document
    doc.build(content)
    buffer.seek(0)
    return buffer


@login_required
def print_absen(request):
    if request.method == 'POST':
        karyawan = request.POST['karyawan']
        bulan_str = request.POST['bulan']
        bulan = datetime.strptime(bulan_str, "%Y-%m-%d").date()
        data = Absen.objects.filter(
            Q(karyawan__nip=karyawan) & Q(tgl_absen__month=bulan.month)
            & Q(tgl_absen__year=bulan.year))
        company_name = "PT. VISI KARYA PRAKARSA"
        company_address = "Jl. Langit No. 123, Kota Angkasa"

        if data:
            nama = data[0].karyawan.nama
            bagian = data[0].karyawan.kode_bagian.nama_bagian
            hadir = data.filter(status="Hadir").count()
            izin = data.filter(status="Izin").count()
            sakit = data.filter(status="Sakit").count()
            tk = data.filter(status="Tidak Masuk").count()
            bulan_indo = nama_bulan(data[0].tgl_absen.month)
            hari_indo = nama_hari(data[0].tgl_absen.weekday())
            tahun = data[0].tgl_absen.year

            full_data = {
                "nama": nama,
                "bagian": bagian,
                "tahun": tahun,
                "hadir": hadir,
                "izin": izin,
                "sakit": sakit,
                "tk": tk,
                "bulan_indo": bulan_indo,
                "hari_indo": hari_indo,
                "data": data
            }

            print(full_data['nama'])

            pdf_buffer = create_letter_template_bytesio(
                company_name, company_address, full_data)

            return FileResponse(pdf_buffer,
                                as_attachment=False,
                                filename="{}-{}-{}.pdf".format(
                                    full_data['nama'], full_data['bulan_indo'],
                                    full_data['tahun']))
        else:
            return render(request, '404.html')
    else:
        form = PrintAbsenForm()
        context = {"form": form}
        return render(request, 'attendance/laporan.html', context)


# API for absen fungsinya agar bisa di akses lewat REST


@api_view(['GET', 'POST'])
# @permission_classes([IsAuthenticated])
def absen_api(request):

    if request.method == "GET":
        absen = Absen.objects.all()
        serializer = AbsenSerializer(absen, many=True)
        return Response(serializer.data)

    elif request.method == "POST":
        data = request.data

        try:
            karyawan = Karyawan.objects.get(
                id_sidik_jari=data["id_sidik_jari"])
        except Bagian.DoesNotExist:
            return HttpResponse(status=404)

        data_n = {
            "karyawan": karyawan.nip,
            "tgl_absen": date.today(),
            "jam_datang": request.POST.get('jam_datang', None),
            "jam_pulang": request.POST.get('jam_pulang', None),
            "status": request.POST.get('status', None)
        }

        serializer = AbsenSerializer(data=data_n)

        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


##############################################################################

# Login View


def login_view(request):
    context = {"login_view": "active"}
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect("home")
        else:
            return render(request, "registration/gagal_login.html")
    return render(request, "registration/login.html", context)


def logout_view(request):
    logout(request)
    return redirect("login")


##############################################################################

# Semua Funsional View


@login_required
def home(request):
    return render(request, "attendance/home.html")


@login_required
def karyawanlist(request, page):
    karyawan = Karyawan.objects.all().order_by("nip")
    paginator = Paginator(karyawan, per_page=10)
    page_object = paginator.get_page(page)
    page_object.adjusted_elided_pages = paginator.get_elided_page_range(page)
    context = {"page_obj": page_object}
    return render(request, "attendance/karyawan_list.html", context)


@login_required
def karyawansearch(request, page):
    if request.method == 'POST':
        search_query = request.POST['search_query']
        karyawan = Karyawan.objects.filter(nip=search_query)
        paginator = Paginator(karyawan, per_page=10)
        page_object = paginator.get_page(page)
        page_object.adjusted_elided_pages = paginator.get_elided_page_range(
            page)
        context = {"page_obj": page_object}
        return render(request, 'attendance/karyawan_list.html', context)
    else:
        return render(request, 'attendance/karyawan_list.html')


class KaryawanCreate(LoginRequiredMixin, CreateView):
    model = Karyawan
    template_name = "attendance/karyawan_create_form.html"
    form_class = KaryawanCreateForm


class KaryawanUpdate(LoginRequiredMixin, UpdateView):
    model = Karyawan
    template_name = "attendance/karyawan_update_form.html"
    form_class = KaryawanUpdateForm


class KaryawanDelete(LoginRequiredMixin, DeleteView):
    model = Karyawan
    template_name = "attendance/karyawan_delete_form.html"
    success_url = "/karyawan/list/1"


@login_required
def bagianlist(request, page):
    bagian = Bagian.objects.all().order_by("kode_bagian")
    paginator = Paginator(bagian, per_page=10)
    page_object = paginator.get_page(page)
    page_object.adjusted_elided_pages = paginator.get_elided_page_range(page)
    context = {"page_obj": page_object}
    return render(request, "attendance/bagian_list.html", context)


@login_required
def bagiansearch(request, page):
    if request.method == 'POST':
        search_query = request.POST['search_query']
        bagian = Bagian.objects.filter(kode_bagian=search_query)
        paginator = Paginator(bagian, per_page=10)
        page_object = paginator.get_page(page)
        page_object.adjusted_elided_pages = paginator.get_elided_page_range(
            page)
        context = {"page_obj": page_object}
        return render(request, 'attendance/bagian_list.html', context)
    else:
        return render(request, 'attendance/bagian_list.html')


class BagianCreate(LoginRequiredMixin, CreateView):
    model = Bagian
    template_name = "attendance/bagian_create_form.html"
    form_class = BagianCreateForm


class BagianUpdate(LoginRequiredMixin, UpdateView):
    model = Bagian
    template_name = "attendance/bagian_update_form.html"
    form_class = BagianUpdateForm


class BagianDelete(LoginRequiredMixin, DeleteView):
    model = Bagian
    template_name = "attendance/bagian_delete_form.html"
    success_url = "/bagian/list/1"


@login_required
def absenlist(request, page):
    absen = Absen.objects.all().order_by("tgl_absen")
    paginator = Paginator(absen, per_page=10)
    page_object = paginator.get_page(page)
    page_object.adjusted_elided_pages = paginator.get_elided_page_range(page)
    form = SearchAbsenForm(request.POST)
    context = {"page_obj": page_object, "form": form}
    return render(request, "attendance/absen_list.html", context)


class AbsenCreate(LoginRequiredMixin, CreateView):
    model = Absen
    template_name = "attendance/absen_create_form.html"
    form_class = AbsenCreateForm

    def get_form(self):
        form = super().get_form()
        form.fields['tgl_absen'].widget = DatePickerInput()
        return form


class AbsenUpdate(LoginRequiredMixin, UpdateView):
    model = Absen
    template_name = "attendance/absen_update_form.html"
    form_class = AbsenUpdateForm

    def get_form(self):
        form = super().get_form()
        return form


class AbsenDelete(LoginRequiredMixin, DeleteView):
    model = Absen
    template_name = "attendance/absen_delete_form.html"
    success_url = "/absen/list/1"


@login_required
def absensearch(request, search_query, page):
    if request.method == 'POST':
        search_query = request.POST['tgl_absen']
        absen = Absen.objects.filter(tgl_absen=search_query)
        paginator = Paginator(absen, per_page=10)
        page_object = paginator.get_page(page)
        page_object.adjusted_elided_pages = paginator.get_elided_page_range(
            page)
        form = SearchAbsenForm(request.POST)
        context = {
            "page_obj": page_object,
            "form": form,
            "search_query": search_query
        }
        return render(request, 'attendance/absen_search.html', context)
    else:
        absen = Absen.objects.filter(tgl_absen=search_query)
        paginator = Paginator(absen, per_page=10)
        page_object = paginator.get_page(page)
        form = SearchAbsenForm()
        page_object.adjusted_elided_pages = paginator.get_elided_page_range(
            page)
        context = {
            "page_obj": page_object,
            "form": form,
            "search_query": search_query
        }
        return render(request, 'attendance/absen_search.html', context)


@login_required
def settinglist(request):
    setting = Setting.objects.all()
    context = {"setting": setting}
    return render(request, "attendance/setting.html", context)


class SettingUpdate(LoginRequiredMixin, UpdateView):
    model = Setting
    template_name = "attendance/setting_update_form.html"
    form_class = SettingUpdateForm

    def get_form(self):
        form = super().get_form()
        form.fields['jam_datang'].widget = TimePickerInput()
        form.fields['jam_pulang'].widget = TimePickerInput()
        return form
