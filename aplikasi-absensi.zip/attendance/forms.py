from django import forms
from .models import Karyawan, Bagian, Absen, Setting
from bootstrap_datepicker_plus.widgets import DatePickerInput, MonthPickerInput


class KaryawanCreateForm(forms.ModelForm):
    class Meta:
        model = Karyawan
        fields = "__all__"
        labels = {
            'kode_bagian': 'Kode Departemen',
        }


class KaryawanUpdateForm(forms.ModelForm):
    class Meta:
        model = Karyawan
        fields = ("nama", "no_telp", "kode_bagian")
        labels = {
            'kode_bagian': 'Kode Departemen',
        }


class BagianCreateForm(forms.ModelForm):
    class Meta:
        model = Bagian
        fields = "__all__"
        labels = {
            'kode_bagian': 'Kode Departemen',
            'nama_bagian': 'Nama Departemen'
        }


class BagianUpdateForm(forms.ModelForm):
    class Meta:
        model = Bagian
        fields = "__all__"
        labels = {
            'kode_bagian': 'Kode Departemen',
            'nama_bagian': 'Nama Departemen'
        }


STATUS_CHOICES_ADMIN = [
    ('Izin', 'Izin'),
    ('Sakit', 'Sakit'),
    ('Tidak Masuk', 'Tidak Masuk'),
]


class AbsenCreateForm(forms.ModelForm):
    status = forms.ChoiceField(choices=STATUS_CHOICES_ADMIN, required=False)

    class Meta:
        model = Absen
        fields = ("karyawan", "tgl_absen", "status", "keterangan")


class AbsenUpdateForm(forms.ModelForm):
    class Meta:
        model = Absen
        fields = ("status", "keterangan")


class SearchAbsenForm(forms.Form):
    tgl_absen = forms.DateField(required=False,
                                label=False,
                                widget=DatePickerInput(
                                    attrs={'placeholder': 'Cari Tanggal'}, ))


class SettingUpdateForm(forms.ModelForm):
    class Meta:
        model = Setting
        fields = "__all__"


class DateInput(forms.DateInput):
    input_type = 'date'


class PrintAbsenForm(forms.Form):
    karyawan = forms.ModelChoiceField(queryset=Karyawan.objects.all())
    bulan = forms.DateField(required=True,
                            label=False,
                            widget=MonthPickerInput(
                                attrs={'placeholder': 'Bulan, Tahun'}, ))
