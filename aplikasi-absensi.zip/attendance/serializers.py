from .models import Absen
from rest_framework import serializers

class AbsenSerializer(serializers.ModelSerializer):
    class Meta:
        model = Absen
        fields = ["karyawan", "tgl_absen", "jam_datang", "jam_pulang", "status"]
