# import models dari library django.db
from django.db import models

import datetime
"""
fungsi file models.py ini untuk membuat model database 
yang nantinya akan di migrate untuk bisa dibuatkan sqlite
dan memudahkan pengolahan database
oleh django
"""


# model database Bagian :
class Bagian(models.Model):
    class Meta:
        # funsinya agar nama tabel di admin site tidak diakhiri s
        verbose_name_plural = 'Bagian'

    # kode_bagian memiliki tipe data Char dan max panjangnya 5 dan beratribur unique
    kode_bagian = models.CharField(max_length=5, unique=True)

    # nama_bagian memiliki tipe data Char dan max panjangnya 30
    nama_bagian = models.CharField(max_length=30)

    def __str__(self):
        # funsinya agar di admin site ter print kode_bagian nya saja
        return self.kode_bagian

    def get_absolute_url(self):
        return '/bagian/list/1'


# model database Karyawan :
class Karyawan(models.Model):
    class Meta:
        # funsinya agar nama tabel di admin site tidak diakhiri s
        verbose_name_plural = 'Karyawan'

    # nip memiliki tipe data Char dengan panjang 30, dan primary key
    nip = models.CharField(max_length=30, primary_key=True)

    # id_sidik_jari memiliki tipe data integer dan unique
    id_sidik_jari = models.IntegerField(unique=True)

    # nama memiliki tipe data char dengan panjang 50
    nama = models.CharField(max_length=50)

    # no_telp memiliki tipe data char dengan panjang 24
    no_telp = models.CharField(max_length=24)

    # kode_bagian merupakan sebuah field yang berisikan data dari model Bagian
    # kode_bagian adalah Foreignkey dari model Bagian
    kode_bagian = models.ForeignKey(Bagian, on_delete=models.CASCADE)

    def __str__(self):
        # funsinya agar di admin site ter print nama nya saja
        return self.nama

    def get_absolute_url(self):
        return '/karyawan/list/1'


# model database Absen :
class Absen(models.Model):
    class Meta:
        # funsinya agar nama tabel di admin site tidak diakhiri s
        verbose_name_plural = 'Absen'

    # STATUS_CHOICES merupakan variable list dari enum atau pilihan
    # yang nanti akan menjadi pilihan pada field status
    STATUS_CHOICES = [
        ('Hadir', 'Hadir'),
        ('Izin', 'Izin'),
        ('Sakit', 'Sakit'),
        ('Tidak Masuk', 'Tidak Masuk'),
    ]

    # primary key + auto icrement
    id_absen = models.AutoField(primary_key=True)

    # karyawan merupakan foreignkey dari model Karyawan
    karyawan = models.ForeignKey(Karyawan, on_delete=models.CASCADE)

    # tgl_absen memiliki tipe data Date atau Tanggal
    tgl_absen = models.DateField()

    # jam_datang memiliki tipe data Time atau Waktu
    # jam_datang bisa tidak di isi
    jam_datang = models.TimeField(null=True, blank=True)

    # jam_pulang memiliki tipe data Time atau Waktu
    # jam_pulang bisa tidak di isi
    jam_pulang = models.TimeField(null=True, blank=True)

    # status memiliki tipe Char disertai dengan pilihan
    # pilihan untuk status ada pada variable STATUS_CHOICES
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)

    # keterangan memiliki tipe data Char dengan panjang 300
    # dan keterangan ini bisa tidak di isi
    keterangan = models.CharField(max_length=300, null=True, blank=True)

    def __str__(self):
        # funsinya agar di admin site ter print nama + tanggal absen
        return f"{self.karyawan.nama} | {self.tgl_absen.strftime('%d-%m-%Y')}"

    def get_absolute_url(self):
        return '/absen/list/1'


class Setting(models.Model):
    jam_datang = models.TimeField(null=True,
                                  blank=True,
                                  default=datetime.time(7, 00))
    jam_pulang = models.TimeField(null=True,
                                  blank=True,
                                  default=datetime.time(15, 00))

    def get_absolute_url(self):
        return '/setting/'
