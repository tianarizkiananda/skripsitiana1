from django.contrib import admin

# Register your models here.
from .models import Absen, Karyawan, Bagian, Setting

# Registrasi model agar bisa di olah di bagian admin site
admin.site.register(Absen)
admin.site.register(Karyawan)
admin.site.register(Bagian)
admin.site.register(Setting)